package com.company;

import java.util.List;


public class WorkWithConsol {


    public static void print(List<String> list) {
        for (String i:list) {
            System.out.println(i);
        }
    }
}
